return {
  no_consumer = true,
  fields = {
    hide_credentials = {type = "boolean", default = false}
  }
}
