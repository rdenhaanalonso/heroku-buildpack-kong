-- Invalid module (syntax error) for utils.load_module_if_exists unit tests.
-- Assert that load_module_if_exists throws an error helps for development, where one could
-- be confused as to the reason why his or her plugin doesn't load. (not implemented or has an error)

local a = "hello",
